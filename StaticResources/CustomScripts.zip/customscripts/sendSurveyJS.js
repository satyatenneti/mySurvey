$(document).ready(function(){
        $('div.section').hide();
        $('input.control-button').hide();
        $('select.sender-list').click(function(){
            if($(this).find('option:selected').length > 0 ) {
               $('input.control-button').show();
            } else {
                $('input.control-button').hide();
            }
            
        });
        $('[id*="external-emails"]').bind('input change', function(){
            if(this.value.length) {
                $('input.control-button').removeAttr('disabled');
                $('input.control-button').show();
            } else {
                $('input.control-button').hide();
            }
        });            
        $('#send-form-to-select').change(function(){
            var sectionToDisplay = $('#send-form-to-select option:selected').val();
            $('[id*="sendTo"]').val(sectionToDisplay);

            if(sectionToDisplay != 'users' && sectionToDisplay != 'contacts') {
                $('input.control-button').hide();
            }else {
                $('input.control-button').show();
            }
            $('div.section').hide();                    
            $('select option:selected').each(function(){$(this).removeAttr('selected')});
            $('#'+sectionToDisplay).show();
        });

        //Initialize the datatable
        $('#contacttable').dataTable();
        $('#usertable').dataTable();
    });

    function doValidateAndSendForm() {

        if($('#others').is(':visible')) { 
            var success = ValidateEmails();   
            if(!success) {
                $('#email-error').show();
                $('input.control-button').hide();
                 return;
            }
        }   

        sendSurveyForm();
    }

    function ValidateEmails() {  
      var emailList= $('[id*="external-emails"]').val().split(',');
        for (i=0;i<emailList.length;i++)
        {
           var regex = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
           if(!regex.test(emailList[i].trim()))
           return false;
        }
        return true;
    }